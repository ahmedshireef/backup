from fbapp.models import *
from django.contrib import admin

admin.site.register(UserProfile)